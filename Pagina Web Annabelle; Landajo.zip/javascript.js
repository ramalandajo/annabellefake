function esconderTodos() {
  document.getElementById("data").style.display = "none";
  document.getElementById("synopsis").style.display = "none";
  document.getElementById("history").style.display = "none";
  document.getElementById("universo").style.display = "none";  
}

function verPersonaje (idDelPersonaje){
 esconderTodos();
  //resetTodos();
  //document.getElementById(idDelPersonaje).style.color = "blue";
  //document.getElementById(idDelPersonaje).style.width = "600px";
  document.getElementById(idDelPersonaje).style.display = "inline-block";
}
